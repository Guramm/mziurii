```bash
git clone https://github.com/ixtk/protected-text-starter.git

cd frontend
npm i
npm run dev

cd backend

# npm i express და სხვა ბიბლიოთეკები...
# npm run dev (package.json-ში დაამატეთ dev სკრიპტი)
```
