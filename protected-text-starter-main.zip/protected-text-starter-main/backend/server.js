const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require("bcrypt")
const Note = require('./models/note');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:---/notes', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
}).catch(err => {
  console.error('Error connecting to MongoDB:', err.message);
});

// Define routes
app.post('/notes', async (req, res) => {
  try {
    const { title, text, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const note = new Note({
      title,
      text,
      password : hashedPassword
    }); 
    await note.save();
    res.status(201).json({ message: 'Note saved successfully' });
  } catch (error) {
    console.error('Error saving note:', error.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
